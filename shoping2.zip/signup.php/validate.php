<?php 

	$fname=$_REQUEST['fname'];
	$lname=$_REQUEST['lname'];
	$username=$_REQUEST['username'];
	$pass=$_REQUEST['pass'];	
	$email=$_REQUEST['email'];
	$con=mysqli_connect("localhost:3306","root","root");
	mysqli_select_db($con,'dac1131');
	if($con){
			$query="insert into user_regi values('$fname','$lname','$username','$pass','$email')";
			if(mysqli_query($con, $query)){
				echo "REGISTRAION SUCCESSFULL";
				
			}
			else{
				echo "REGISTRAION SUCCESSFULL";
			}
	}
	else{
		echo "database is not selected";
	}
	echo "<br><a href='signup.php'>BACK TO LOGIN PAGE</a>";
?>