<?php
$var1=$_REQUEST['submit'];



?>
