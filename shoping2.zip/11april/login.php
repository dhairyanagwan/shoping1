<form action="validate.php" >

<input type="submit" name="submit" value="connectdb" >
<input type="submit" name="submit" value="createDB" >
<br>
<br>
<br>
ENTER THE  EMPLOYEE ID <input type="text" name="id" >
<br>
<br>
ENTER THE  NAME <input type="text" name="ename" >
<br>
<br>
ENTER THE DESIGNTION <input type="text" name="des" >
<br>
<br>
ENTER THE BASIC<input type="text" name="basic" >
<input type="submit" name="submit" value="insert" >
<br>
<br>
<br>
<br>
<input type="submit" name="submit" value="display" >
<br>
<br>
ENTER THE TABLE NAME YOU WANT TO CREATE<input type="text" name="name" >
<input type="submit" name="submit" value="createtable">
</form>
