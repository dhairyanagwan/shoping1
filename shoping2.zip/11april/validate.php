<?php 
$var1=$_REQUEST['submit'];
session_start();
if ($var1=='connectdb'){
	#echo "the button which clicked is" .$var1;
	require 'dbconnect.php';
	if($con){
		echo "connected successfully";
		echo "<br><a href='login.php'>BACK TO LOGIN PAGE</a>";
	
}
else{
		echo "try again!".mysqli_error($con);
	}
	
	
}
else if ($var1=='createDB'){
#echo "the button which clicked is" .$var1;
	require 'dbconnect.php';
	if($con){
		if(mysqli_select_db($con, 'dac1131'))
		{
			echo "data base selected";
			
		}else{
			echo "database is not selected";
		}
		echo "<br><a href='login.php'>BACK TO LOGIN PAGE</a>";
	}
}
else if ($var1=='createtable')
{
	
	#echo "table name is<br>" .$_REQUEST['name'];
	
	require 'dbconnect.php';
	if($con){
		if(mysqli_select_db($con, 'dac1131'))
			$var1=$_REQUEST['name'];
		$_SESSION['key1']=$var1;
		
			$query="create table .$var1 (eid int, ename char(20), designation char(20), basic int)";
			if(mysqli_query($con, $query)){
				echo "table created";
			}
			else{
				echo "table is not created";
		}
		}
		else{
			echo "database is not selected";
		}
		echo "<br><a href='login.php'>BACK TO LOGIN PAGE</a>";
}


else if ($var1=="insert"){
	echo "data".$_SESSION['key1'];
	#echo "the button which clicked is" .$var1;
	$id=$_REQUEST['id'];
	$ename=$_REQUEST['ename'];
	$des=$_REQUEST['des'];
	$basic=$_REQUEST['basic'];
	require 'dbconnect.php';
	if($con){
		if(mysqli_select_db($con, 'dac1131'))
			$var1=$_REQUEST['name'];
			$query="insert into ".$_SESSION['key1']." values($id,'$ename','$des',$basic)";
			if(mysqli_query($con, $query)){
				echo "INSERTED";
			}
			else{
				echo "NOT INSERTED";
			}
	}
	else{
		echo "database is not selected";
	}
	echo "<br><a href='login.php'>BACK TO LOGIN PAGE</a>";
}


else if ($var1=='display'){
	
	require 'dbconnect.php';
	if($con){
		if(mysqli_select_db($con, 'dac1131'))
			echo "DATA ".$_SESSION['key1'];
			$query="select * from ".$_SESSION['key1']; 
			$result =mysqli_query($con,$query);
			
			echo "<table border=1 height=200 width=200 >";
			while ($row=mysqli_fetch_array($result))
			{
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['ename']."</td>";
				echo "<td>".$row['designation']."</td>";
				echo "<td>".$row['basic']."</td>";
				
				echo "</tr>";
			}
			echo "</table>";
	}
	else
	{
		
		echo "Error ".mysql_error();
	}
	
}
else
{
	echo "Error ".mysql_error();
}
?>

