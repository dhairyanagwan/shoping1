<?php
$con=mysqli_connect("localhost:3306","root","root",'dac1131');

?>